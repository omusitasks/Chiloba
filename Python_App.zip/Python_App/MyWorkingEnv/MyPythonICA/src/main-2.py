from student import Student

class CSStudent(Student):
    cs_optional_modules = [("CS101", "Python Programming"), ("CS102", "Database Management")]

    def __init__(self, name, id, cs_modules=None, optional_modules=None):
        super().__init__(name, id, "CS", optional_modules)
        if cs_modules is not None:
            for module_code, module_name in cs_modules:
                if (module_code, module_name) not in self.cs_optional_modules:
                    raise ValueError(f"{module_code} - {module_name} is not a valid CS optional module.")
            self.cs_modules = cs_modules
        else:
            self.cs_modules = self.cs_optional_modules
    
    def check_course(self):
        return 'CS'