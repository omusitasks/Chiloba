from datetime import datetime

class Student:
    def __init__(self, first_name, last_name, gender, compulsory_modules):
        self.id = None # assigned later
        self.first_name = first_name
        self.middle_name = None
        self.last_name = last_name
        self.gender = gender
        self.email = None # assigned later
        self.registration_datetime = datetime.now()
        self.compulsory_modules = compulsory_modules
        self.optional_modules = []

    def set_id(self, id):
        self.id = id
        self.email = f"{id}@mono.ac.uk"

    def add_optional_module(self, module_code, module_name):
        if module_code in [module[0] for module in self.optional_modules]:
            print(f"{module_code} is already selected")
        else:
            self.optional_modules.append((module_code, module_name))

    def remove_optional_module(self, module_code):
        if module_code not in [module[0] for module in self.optional_modules]:
            print(f"{module_code} is not selected")
        else:
            self.optional_modules = [(code, name) for code, name in self.optional_modules if code != module_code]

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.gender}), ID: {self.id}, Email: {self.email}"



