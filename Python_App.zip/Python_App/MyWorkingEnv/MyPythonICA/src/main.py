import datetime

class Student:
    def __init__(self, first_name, last_name, gender, compulsory_modules, optional_modules=None, middle_name=None, registration_datetime=None):
        self.name = {'first name': first_name, 'middle name': middle_name, 'last name': last_name}
        self.gender = gender
        self.email = None
        self.compulsory_modules = compulsory_modules or []
        if optional_modules:
            for module_code, module_name in optional_modules:
                if (module_code, module_name) not in self.optional_modules:
                    raise ValueError(f"Module {module_code} is not available in optional modules")
            self.optional_modules = optional_modules
        else:
            self.optional_modules = [('CIS001', 'Introduction to Computing'), ('MTH001', 'Introduction to Mathematics')]
        self.registration_datetime = registration_datetime or datetime.datetime.now()
        self.id = None

    def generate_email(self):
        if not self.id:
            raise ValueError("Student ID not set")
        self.email = f"{self.id}@mono.ac.uk"

    def set_id(self, id):
        self.id = id
        self.generate_email()

    def add_optional_module(self, module_code, module_name):
        for code, name in self.optional_modules:
            if code == module_code:
                raise ValueError(f"Module {module_code} already added")
        self.optional_modules.append((module_code, module_name))

    def remove_optional_module(self, module_code):
        for code, name in self.optional_modules:
            if code == module_code:
                self.optional_modules.remove((code, name))
                return
        raise ValueError(f"Module {module_code} not found in optional modules")

    def convert_gender_to_title(self):
        if self.gender == 'M':
            return 'Mr.'
        elif self.gender == 'F':
            return 'Ms.'
        else:
            raise ValueError("Invalid gender")

    def is_registered_before(self, datetime_obj):
        return self.registration_datetime < datetime_obj

    def is_registered_after(self, datetime_obj):
        return self.registration_datetime > datetime_obj
    
    def is_registered_between(self, start_datetime_obj, end_datetime_obj):
        return start_datetime_obj <= self.registration_datetime <= end_datetime_obj
    
    def update_optional_module(self, old_module_code, new_module):
        new_module_code, new_module_name = new_module
        if old_module_code == new_module_code:
            return
        old_module_found = False
        new_module_found = False
        for code, name in self.optional_modules:
            if code == old_module_code:
                old_module_found = True
            if code == new_module_code:
                new_module_found = True
        if not old_module_found:
            raise ValueError(f"Module {old_module_code} not found in optional modules")
        if not new_module_found:
            raise ValueError(f"Module {new_module_code} not found in optional modules")
        self.optional_modules = [(new_module_code, new_module_name) if code == old_module_code else (code, name) for code, name in self.optional_modules]

    def get_info_string(self):
        self.generate_email()
        title = self.convert_gender_to_title()
        first_name = self.name['first name']
        middle_name = self.name['middle name'] or ''
        last_name = self.name['last name']
        email = self.email
        registration_datetime_str = self.registration_datetime.strftime('%Y-%m-%d:%H-%M-%S')
        return f"{title} {first_name} {middle_name} {last_name}, email: {email}, registration datetime: {registration_datetime_str}"


class CSStudent(Student):
    cs_optional_modules = [("CS101", "Python Programming"), ("CS102", "Database Management")]

    def __init__(self, name, id, cs_modules=None, optional_modules=None):
        super().__init__(name, id, "CS", optional_modules)
        if cs_modules is not None:
            for module_code, module_name in cs_modules:
                if (module_code, module_name) not in self.cs_optional_modules:
                    raise ValueError(f"{module_code} - {module_name} is not a valid CS optional module.")
            self.cs_modules = cs_modules
        else:
            self.cs_modules = self.cs_optional_modules
    
    def check_course(self):
        return 'CS'


class DSStudent(Student):
    # DS optional module list
    DS_MODULES = [("DS101", "Introduction to Data Science"), 
                  ("DS102", "Data Wrangling"), 
                  ("DS103", "Data Visualization"), 
                  ("DS104", "Statistics for Data Science")]

    def __init__(self, name, age, gender, student_id, course, optional_modules=None, ds_modules=None):
        super().__init__(name, age, gender, student_id, course, optional_modules)
        if ds_modules is None:
            self.ds_modules = [("DS101", "Introduction to Data Science"), ("DS102", "Data Wrangling")]
        else:
            for module_code, module_name in ds_modules:
                if (module_code, module_name) not in self.DS_MODULES:
                    raise ValueError(f"{module_code} is not a valid DS optional module.")
            self.ds_modules = ds_modules
    
    def check_course(self):
        return "DS"
