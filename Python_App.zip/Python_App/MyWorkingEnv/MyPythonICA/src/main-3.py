class DSStudent(Student):
    # DS optional module list
    DS_MODULES = [("DS101", "Introduction to Data Science"), 
                  ("DS102", "Data Wrangling"), 
                  ("DS103", "Data Visualization"), 
                  ("DS104", "Statistics for Data Science")]

    def __init__(self, name, age, gender, student_id, course, optional_modules=None, ds_modules=None):
        super().__init__(name, age, gender, student_id, course, optional_modules)
        if ds_modules is None:
            self.ds_modules = [("DS101", "Introduction to Data Science"), ("DS102", "Data Wrangling")]
        else:
            for module_code, module_name in ds_modules:
                if (module_code, module_name) not in self.DS_MODULES:
                    raise ValueError(f"{module_code} is not a valid DS optional module.")
            self.ds_modules = ds_modules
    
    def check_course(self):
        return "DS"
